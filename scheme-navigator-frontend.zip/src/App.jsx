import { useState, useEffect, useRef, useCallback } from "react"
import axios from "axios"
import {
  Landmark,
  Moon,
  Sun,
  Sparkles,
  Search,
  MessageCircle,
  X,
  Send,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ArrowRight,
  Tractor,
  GraduationCap,
  HardHat,
  Briefcase,
  Store,
  UserX,
  Users,
  Loader2,
  IndianRupee,
  MapPin,
  Building2,
  Layers,
  Search as SearchIcon,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts"

const API_BASE = "http://127.0.0.1:8000"

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
  "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
  "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
  "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry",
]

const CASTES = [
  { value: "general", label: "General" },
  { value: "obc", label: "OBC" },
  { value: "sc", label: "SC" },
  { value: "st", label: "ST" },
]

const OCCUPATIONS = [
  { value: "farmer", label: "Farmer", Icon: Tractor },
  { value: "student", label: "Student", Icon: GraduationCap },
  { value: "labor", label: "Labor", Icon: HardHat },
  { value: "entrepreneur", label: "Entrepreneur", Icon: Briefcase },
  { value: "self-employed", label: "Self-Employed", Icon: Store },
  { value: "unemployed", label: "Unemployed", Icon: UserX },
  { value: "any", label: "Any", Icon: Users },
]

/* ---------- Demo fallback data (used if backend unreachable) ---------- */
const DEMO_SCHEMES = [
  {
    id: 1,
    title: "PM-KISAN Samman Nidhi",
    ministry: "Ministry of Agriculture & Farmers Welfare",
    state: null,
    type: "central",
    eligible: true,
    description:
      "Income support of ₹6,000 per year in three equal installments to all landholding farmer families to supplement their financial needs for agriculture and allied activities.",
    benefits: "₹6,000/year direct benefit transfer",
    reasons: ["Occupation: Farmer", "Income below threshold", "Indian citizen"],
    documents: ["Aadhaar Card", "Land Records", "Bank Account Passbook"],
    url: "https://pmkisan.gov.in",
  },
  {
    id: 2,
    title: "Pradhan Mantri Fasal Bima Yojana",
    ministry: "Ministry of Agriculture & Farmers Welfare",
    state: null,
    type: "central",
    eligible: true,
    description:
      "Comprehensive crop insurance scheme providing financial support to farmers suffering crop loss/damage arising out of unforeseen events.",
    benefits: "Up to ₹2,00,000 crop insurance cover",
    reasons: ["Occupation: Farmer", "Cultivating notified crops"],
    documents: ["Aadhaar Card", "Land Records", "Sowing Certificate"],
    url: "https://pmfby.gov.in",
  },
  {
    id: 3,
    title: "Mahatma Phule Krishi Samman",
    ministry: "Department of Agriculture",
    state: "Maharashtra",
    type: "state",
    eligible: false,
    description:
      "State-level farm loan waiver and support scheme for distressed farmers in Maharashtra with outstanding crop loans.",
    benefits: "Loan waiver up to ₹2,00,000",
    reasons: ["State scheme — domicile check required", "Occupation: Farmer"],
    documents: ["Domicile Certificate", "Loan Documents", "Aadhaar Card"],
    url: "https://krishi.maharashtra.gov.in",
  },
  {
    id: 4,
    title: "National Scheduled Caste Scholarship",
    ministry: "Ministry of Social Justice & Empowerment",
    state: null,
    type: "central",
    eligible: true,
    description:
      "Financial assistance to SC students to pursue higher education, covering tuition fees and maintenance allowance.",
    benefits: "Full tuition + ₹13,500 maintenance/year",
    reasons: ["Caste: SC", "Family income within limit"],
    documents: ["Caste Certificate", "Income Certificate", "Marksheet"],
    url: "https://scholarships.gov.in",
  },
]

/* =================================================================== */
/*  Reusable bits                                                      */
/* =================================================================== */

function useInView(options) {
  const ref = useRef(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setInView(true)
        obs.disconnect()
      }
    }, options || { threshold: 0.3 })
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return [ref, inView]
}

function CountUp({ end, duration = 1500, suffix = "" }) {
  const [ref, inView] = useInView()
  const [val, setVal] = useState(0)
  useEffect(() => {
    if (!inView) return
    let start = null
    let raf
    const step = (ts) => {
      if (!start) start = ts
      const p = Math.min((ts - start) / duration, 1)
      const eased = 1 - Math.pow(1 - p, 3)
      setVal(Math.floor(eased * end))
      if (p < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [inView, end, duration])
  return (
    <span ref={ref}>
      {val.toLocaleString("en-IN")}
      {suffix}
    </span>
  )
}

/* =================================================================== */
/*  Navbar                                                             */
/* =================================================================== */

function Navbar({ dark, toggleDark, lang, setLang }) {
  const links = [
    { label: "Home", id: "hero" },
    { label: "Find Schemes", id: "form" },
    { label: "About", id: "stats" },
  ]
  const langs = ["EN", "हिं", "मर"]
  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })

  return (
    <nav className="fixed top-0 inset-x-0 z-50 glass border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => scrollTo("hero")}
          className="flex items-center gap-2 font-bold text-lg"
        >
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-[var(--primary)]/15 text-[var(--primary)]">
            <Landmark size={20} />
          </span>
          <span>
            Scheme<span className="text-[var(--primary)]">Navigator</span>
          </span>
        </button>

        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => scrollTo(l.id)}
              className="px-4 py-2 rounded-lg text-sm font-medium text-[var(--muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface)] transition-colors"
            >
              {l.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center glass rounded-lg p-0.5">
            {langs.map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                  lang === l
                    ? "bg-[var(--primary)] text-white"
                    : "text-[var(--muted)] hover:text-[var(--foreground)]"
                }`}
              >
                {l}
              </button>
            ))}
          </div>
          <button
            onClick={toggleDark}
            aria-label="Toggle dark mode"
            className="grid place-items-center w-10 h-10 rounded-lg glass hover:text-[var(--primary)] transition-colors"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </div>
    </nav>
  )
}

/* =================================================================== */
/*  Hero                                                               */
/* =================================================================== */

function Hero() {
  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16"
    >
      <div className="aurora">
        <span className="a1" />
        <span className="a2" />
        <span className="a3" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center py-20">
        <div
          className="fade-up inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-sm text-[var(--muted)] mb-8"
          style={{ animationDelay: "0.05s" }}
        >
          <Sparkles size={15} className="text-[var(--primary)]" />
          AI-powered eligibility matching in seconds
        </div>

        <h1
          className="fade-up text-4xl sm:text-6xl font-bold tracking-tight text-balance leading-[1.1]"
          style={{ animationDelay: "0.15s" }}
        >
          Find Government Schemes{" "}
          <span className="text-[var(--primary)]">Made For You</span>
        </h1>

        <p
          className="fade-up mt-6 text-lg text-[var(--muted)] max-w-2xl mx-auto text-pretty leading-relaxed"
          style={{ animationDelay: "0.25s" }}
        >
          Discover central and state welfare schemes you qualify for. Built for
          every citizen of India — rural and urban.
        </p>

        <div
          className="fade-up mt-9 flex flex-col sm:flex-row gap-3 justify-center"
          style={{ animationDelay: "0.35s" }}
        >
          <button
            onClick={() => scrollTo("form")}
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-[var(--primary)] text-white font-semibold hover:bg-[var(--primary-dark)] transition-all hover:scale-[1.03] shadow-lg shadow-[var(--primary)]/25"
          >
            <Search size={18} />
            Check My Eligibility
          </button>
          <button
            onClick={() => window.dispatchEvent(new Event("open-chat"))}
            className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl glass font-semibold hover:text-[var(--primary)] transition-all hover:scale-[1.03]"
          >
            <MessageCircle size={18} />
            Ask AI Assistant
          </button>
        </div>

        <div
          className="fade-up mt-12 inline-flex items-center gap-3 glass rounded-2xl px-6 py-4"
          style={{ animationDelay: "0.45s" }}
        >
          <span className="text-3xl font-bold text-[var(--primary)]">
            <CountUp end={3000} suffix="+" />
          </span>
          <span className="text-sm text-[var(--muted)] text-left leading-tight">
            schemes across
            <br />
            India
          </span>
        </div>
      </div>
    </section>
  )
}

/* =================================================================== */
/*  Searchable state dropdown                                          */
/* =================================================================== */

function StateSelect({ value, onChange, placeholder }) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const wrapRef = useRef(null)

  useEffect(() => {
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [])

  const filtered = INDIAN_STATES.filter((s) =>
    s.toLowerCase().includes(query.toLowerCase()),
  )

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="focus-glow w-full flex items-center justify-between gap-2 rounded-xl glass px-4 py-3 text-left transition-colors"
      >
        <span className={value ? "" : "text-[var(--muted)]"}>
          {value || placeholder}
        </span>
        <ChevronDown
          size={18}
          className={`text-[var(--muted)] transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && (
        <div className="absolute z-30 mt-2 w-full glass rounded-xl p-2 shadow-2xl">
          <div className="flex items-center gap-2 px-2 py-1.5 mb-1 rounded-lg bg-[var(--surface)]">
            <SearchIcon size={15} className="text-[var(--muted)]" />
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search states..."
              className="bg-transparent outline-none text-sm w-full"
            />
          </div>
          <div className="max-h-56 overflow-y-auto thin-scroll">
            {filtered.length === 0 && (
              <p className="px-3 py-2 text-sm text-[var(--muted)]">No match</p>
            )}
            {filtered.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => {
                  onChange(s)
                  setOpen(false)
                  setQuery("")
                }}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors hover:bg-[var(--primary)]/15 ${
                  value === s ? "text-[var(--primary)] font-medium" : ""
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

/* =================================================================== */
/*  Profile Form                                                       */
/* =================================================================== */

function ProfileForm({ onResults, loading, setLoading, setError }) {
  const [age, setAge] = useState(30)
  const [gender, setGender] = useState("male")
  const [caste, setCaste] = useState("general")
  const [income, setIncome] = useState(150000)
  const [occupation, setOccupation] = useState("farmer")
  const [state, setState] = useState("")
  const [domicileYears, setDomicileYears] = useState(5)
  const [homeState, setHomeState] = useState("")

  const submit = async (e) => {
    e.preventDefault()
    if (!state) {
      setError("Please select your current state.")
      return
    }
    setError("")
    setLoading(true)
    const payload = {
      age: Number(age),
      gender,
      caste,
      income: Number(income),
      occupation,
      domicile_state: state,
      domicile_years: Number(domicileYears),
      home_state: homeState || state,
    }
    try {
      const res = await axios.post(`${API_BASE}/match`, payload, {
        timeout: 12000,
      })
      onResults(res.data, false)
    } catch (err) {
      console.log("[v0] /match request failed:", err.message)
      // Graceful fallback to demo data so the UI remains usable in preview.
      onResults(
        { total: DEMO_SCHEMES.length, schemes: DEMO_SCHEMES },
        true,
      )
      setError(
        "Could not reach the backend at 127.0.0.1:8000 — showing sample results so you can preview the experience.",
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <section id="form" className="relative py-24 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-3xl sm:text-4xl font-bold text-balance">
            Eligibility Checker
          </h2>
          <p className="mt-3 text-[var(--muted)]">
            Tell us about yourself and we&apos;ll match you with schemes.
          </p>
        </div>

        <form onSubmit={submit} className="glass rounded-3xl p-6 sm:p-9 space-y-7">
          {/* Age + Years grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            <Field label="Age">
              <input
                type="number"
                min={0}
                max={120}
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="focus-glow w-full rounded-xl glass px-4 py-3 outline-none"
              />
            </Field>
            <Field label="Years of residency in current state">
              <input
                type="number"
                min={0}
                max={120}
                value={domicileYears}
                onChange={(e) => setDomicileYears(e.target.value)}
                className="focus-glow w-full rounded-xl glass px-4 py-3 outline-none"
              />
            </Field>
          </div>

          {/* Gender */}
          <Field label="Gender">
            <div className="grid grid-cols-2 gap-3 max-w-sm">
              {["male", "female"].map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`capitalize rounded-xl px-4 py-3 font-medium transition-all ${
                    gender === g
                      ? "bg-[var(--primary)] text-white shadow-lg shadow-[var(--primary)]/25"
                      : "glass hover:text-[var(--primary)]"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </Field>

          {/* Caste */}
          <Field label="Caste Category">
            <div className="flex flex-wrap gap-2.5">
              {CASTES.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setCaste(c.value)}
                  className={`rounded-full px-5 py-2 text-sm font-medium transition-all ${
                    caste === c.value
                      ? "bg-[var(--primary)] text-white shadow-lg shadow-[var(--primary)]/25"
                      : "glass hover:text-[var(--primary)]"
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </Field>

          {/* Income */}
          <Field label="Annual Income">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <input
                type="range"
                min={0}
                max={1000000}
                step={5000}
                value={income}
                onChange={(e) => setIncome(e.target.value)}
                className="flex-1"
              />
              <div className="focus-glow flex items-center gap-1 rounded-xl glass px-3 py-2 sm:w-48">
                <IndianRupee size={16} className="text-[var(--muted)]" />
                <input
                  type="number"
                  min={0}
                  value={income}
                  onChange={(e) => setIncome(e.target.value)}
                  className="w-full bg-transparent outline-none"
                />
              </div>
            </div>
            <p className="mt-1.5 text-xs text-[var(--muted)]">
              ₹{Number(income).toLocaleString("en-IN")} per year
            </p>
          </Field>

          {/* Occupation icon grid */}
          <Field label="Occupation">
            <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              {OCCUPATIONS.map(({ value, label, Icon }) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setOccupation(value)}
                  className={`flex flex-col items-center gap-2 rounded-2xl px-2 py-4 text-xs font-medium transition-all ${
                    occupation === value
                      ? "bg-[var(--primary)] text-white shadow-lg shadow-[var(--primary)]/25 scale-105"
                      : "glass hover:text-[var(--primary)]"
                  }`}
                >
                  <Icon size={22} />
                  {label}
                </button>
              ))}
            </div>
          </Field>

          {/* States */}
          <div className="grid sm:grid-cols-2 gap-6">
            <Field label="Current State">
              <StateSelect
                value={state}
                onChange={setState}
                placeholder="Select your state"
              />
            </Field>
            <Field label="Home State (for migrant detection)">
              <StateSelect
                value={homeState}
                onChange={setHomeState}
                placeholder="Select home state"
              />
            </Field>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className={`w-full flex items-center justify-center gap-2 rounded-xl bg-[var(--primary)] text-white font-semibold py-4 text-lg transition-all hover:bg-[var(--primary-dark)] disabled:opacity-80 ${
              loading ? "pulse-glow" : "hover:scale-[1.01]"
            }`}
          >
            {loading ? (
              <>
                <Loader2 size={20} className="animate-spin" />
                Matching schemes...
              </>
            ) : (
              <>
                <Sparkles size={20} />
                Find My Schemes
              </>
            )}
          </button>
        </form>
      </div>
    </section>
  )
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-[var(--muted)] mb-2.5">
        {label}
      </label>
      {children}
    </div>
  )
}

/* =================================================================== */
/*  Results                                                            */
/* =================================================================== */

function SchemeCard({ scheme, index }) {
  const [expanded, setExpanded] = useState(false)
  const eligible = scheme.eligible
  const isCentral = scheme.type === "central" || !scheme.state

  return (
    <article
      className="fade-up glass rounded-2xl p-6 flex flex-col"
      style={{ animationDelay: `${index * 0.08}s` }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
            eligible
              ? "bg-[var(--primary)]/15 text-[var(--primary)]"
              : "bg-[var(--amber)]/15 text-[var(--amber)]"
          }`}
        >
          {eligible ? (
            <>
              <CheckCircle2 size={13} /> Fully Eligible
            </>
          ) : (
            <>
              <AlertTriangle size={13} /> Check Domicile
            </>
          )}
        </span>
        <span
          className={`rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide ${
            isCentral
              ? "bg-sky-500/15 text-sky-400"
              : "bg-violet-500/15 text-violet-400"
          }`}
        >
          {isCentral ? "Central" : "State"}
        </span>
      </div>

      <h3 className="text-lg font-bold leading-snug">{scheme.title}</h3>

      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[var(--muted)]">
        {scheme.ministry && (
          <span className="inline-flex items-center gap-1">
            <Building2 size={12} /> {scheme.ministry}
          </span>
        )}
        {scheme.state && (
          <span className="inline-flex items-center gap-1">
            <MapPin size={12} /> {scheme.state}
          </span>
        )}
      </div>

      {scheme.description && (
        <div className="mt-3">
          <p
            className={`text-sm text-[var(--muted)] leading-relaxed ${
              expanded ? "" : "line-clamp-2"
            }`}
          >
            {scheme.description}
          </p>
          <button
            onClick={() => setExpanded((e) => !e)}
            className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-[var(--primary)]"
          >
            {expanded ? (
              <>
                Show less <ChevronUp size={13} />
              </>
            ) : (
              <>
                Read more <ChevronDown size={13} />
              </>
            )}
          </button>
        </div>
      )}

      {scheme.benefits && (
        <div className="mt-3 rounded-xl bg-[var(--primary)]/10 px-3 py-2 text-sm font-semibold text-[var(--primary)]">
          {scheme.benefits}
        </div>
      )}

      {scheme.reasons?.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {scheme.reasons.map((r, i) => (
            <span
              key={i}
              className="rounded-full bg-[var(--primary)]/10 text-[var(--primary)] px-2.5 py-1 text-[11px] font-medium"
            >
              {r}
            </span>
          ))}
        </div>
      )}

      {scheme.documents?.length > 0 && (
        <div className="mt-4">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-[var(--muted)] mb-1.5">
            <FileText size={13} /> Documents needed
          </p>
          <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-[var(--muted)]">
            {scheme.documents.map((d, i) => (
              <li key={i} className="list-disc list-inside">
                {d}
              </li>
            ))}
          </ul>
        </div>
      )}

      <a
        href={scheme.url || "#"}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-5 inline-flex items-center justify-center gap-2 rounded-xl bg-[var(--primary)] text-white font-semibold py-2.5 transition-all hover:bg-[var(--primary-dark)] hover:gap-3"
      >
        Apply Now <ArrowRight size={16} />
      </a>
    </article>
  )
}

function Results({ data, isDemo }) {
  const [filter, setFilter] = useState("all")
  const schemes = data?.schemes || []

  const filtered = schemes.filter((s) => {
    const isCentral = s.type === "central" || !s.state
    if (filter === "all") return true
    if (filter === "central") return isCentral
    if (filter === "state") return !isCentral
    if (filter === "partial") return !s.eligible
    return true
  })

  const filters = [
    { value: "all", label: "All" },
    { value: "central", label: "Central" },
    { value: "state", label: "State" },
    { value: "partial", label: "Partial" },
  ]

  return (
    <section id="results" className="py-16 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold">
              Found{" "}
              <span className="text-[var(--primary)]">{schemes.length}</span>{" "}
              schemes for you
            </h2>
            {isDemo && (
              <p className="mt-1 text-sm text-[var(--amber)]">
                Showing sample data (backend offline)
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={`rounded-full px-4 py-1.5 text-sm font-medium transition-all ${
                  filter === f.value
                    ? "bg-[var(--primary)] text-white"
                    : "glass hover:text-[var(--primary)]"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="glass rounded-3xl py-20 text-center">
            <div className="grid place-items-center w-16 h-16 rounded-2xl bg-[var(--surface)] mx-auto mb-4">
              <Search size={28} className="text-[var(--muted)]" />
            </div>
            <h3 className="text-xl font-bold">No schemes found</h3>
            <p className="mt-2 text-[var(--muted)]">
              Try adjusting your profile or filters to see more matches.
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((s, i) => (
              <SchemeCard key={s.id || i} scheme={s} index={i} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}

/* =================================================================== */
/*  Stats Dashboard                                                    */
/* =================================================================== */

function StatCard({ icon: Icon, label, value, delay }) {
  return (
    <div
      className="fade-up glass rounded-2xl p-6"
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="grid place-items-center w-11 h-11 rounded-xl bg-[var(--primary)]/15 text-[var(--primary)] mb-4">
        <Icon size={22} />
      </div>
      <p className="text-3xl font-bold">
        <CountUp end={value} />
      </p>
      <p className="mt-1 text-sm text-[var(--muted)]">{label}</p>
    </div>
  )
}

function StatsDashboard() {
  const categoryData = [
    { name: "Agriculture", value: 620 },
    { name: "Education", value: 540 },
    { name: "Health", value: 410 },
    { name: "Employment", value: 380 },
    { name: "Housing", value: 290 },
    { name: "Social", value: 760 },
  ]
  const [ref, inView] = useInView({ threshold: 0.2 })

  return (
    <section id="stats" className="py-24 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-balance">
            Schemes at a Glance
          </h2>
          <p className="mt-3 text-[var(--muted)]">
            A growing database covering every category of welfare.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 mb-10">
          <StatCard icon={Layers} label="Total Schemes" value={3000} delay={0} />
          <StatCard
            icon={Landmark}
            label="Central Schemes"
            value={740}
            delay={0.1}
          />
          <StatCard
            icon={Building2}
            label="State Schemes"
            value={2260}
            delay={0.2}
          />
          <StatCard
            icon={Layers}
            label="Categories Covered"
            value={28}
            delay={0.3}
          />
        </div>

        <div ref={ref} className="glass rounded-3xl p-5 sm:p-8">
          <h3 className="font-semibold mb-6">Schemes by Category</h3>
          <div className="h-72">
            {inView && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData}>
                  <XAxis
                    dataKey="name"
                    stroke="var(--muted)"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="var(--muted)"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    cursor={{ fill: "rgba(16,185,129,0.08)" }}
                    contentStyle={{
                      background: "var(--background)",
                      border: "1px solid var(--surface-border)",
                      borderRadius: 12,
                      color: "var(--foreground)",
                    }}
                  />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {categoryData.map((_, i) => (
                      <Cell key={i} fill="#10b981" fillOpacity={0.85} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

/* =================================================================== */
/*  AI Chatbot                                                         */
/* =================================================================== */

function Chatbot() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([
    {
      role: "ai",
      text: "Namaste! 🙏 I'm your Scheme Navigator assistant. Ask me anything like \"I am a 40 year old farmer in Maharashtra, what schemes can I get?\"",
    },
  ])
  const [input, setInput] = useState("")
  const [typing, setTyping] = useState(false)
  const scrollRef = useRef(null)

  useEffect(() => {
    const handler = () => setOpen(true)
    window.addEventListener("open-chat", handler)
    return () => window.removeEventListener("open-chat", handler)
  }, [])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 999999, behavior: "smooth" })
  }, [messages, typing])

  const send = async () => {
    const text = input.trim()
    if (!text || typing) return
    setMessages((m) => [...m, { role: "user", text }])
    setInput("")
    setTyping(true)
    try {
      const res = await axios.post(
        `${API_BASE}/chat`,
        { message: text },
        { timeout: 15000 },
      )
      setMessages((m) => [
        ...m,
        { role: "ai", text: res.data?.reply || "I couldn't find an answer." },
      ])
    } catch (err) {
      console.log("[v0] /chat request failed:", err.message)
      setMessages((m) => [
        ...m,
        {
          role: "ai",
          text: "I couldn't reach the AI service at 127.0.0.1:8000 right now. Please make sure the backend is running and try again.",
        },
      ])
    } finally {
      setTyping(false)
    }
  }

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Open AI assistant"
        className="fixed bottom-6 right-6 z-50 grid place-items-center w-14 h-14 rounded-full bg-[var(--primary)] text-white shadow-xl shadow-[var(--primary)]/40 hover:bg-[var(--primary-dark)] transition-all hover:scale-110"
      >
        {open ? <X size={24} /> : <MessageCircle size={24} />}
      </button>

      {/* Panel */}
      {open && (
        <div className="slide-in-right fixed bottom-24 right-6 z-50 w-[calc(100vw-3rem)] sm:w-96 h-[34rem] max-h-[75vh] glass rounded-3xl flex flex-col overflow-hidden shadow-2xl">
          <header className="flex items-center gap-3 px-5 py-4 border-b">
            <span className="grid place-items-center w-9 h-9 rounded-full bg-[var(--primary)]/15 text-[var(--primary)]">
              <Sparkles size={18} />
            </span>
            <div>
              <p className="font-semibold leading-tight">AI Assistant</p>
              <p className="text-xs text-[var(--primary)]">● Online</p>
            </div>
          </header>

          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto thin-scroll px-4 py-4 space-y-3"
          >
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    m.role === "user"
                      ? "bg-[var(--primary)] text-white rounded-br-sm"
                      : "glass rounded-bl-sm"
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex justify-start">
                <div className="glass rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
                  <span className="dot w-2 h-2 rounded-full bg-[var(--muted)]" />
                  <span className="dot w-2 h-2 rounded-full bg-[var(--muted)]" />
                  <span className="dot w-2 h-2 rounded-full bg-[var(--muted)]" />
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t">
            <div className="focus-glow flex items-center gap-2 rounded-xl glass px-3 py-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder="Type your question..."
                className="flex-1 bg-transparent outline-none text-sm"
              />
              <button
                onClick={send}
                disabled={typing || !input.trim()}
                aria-label="Send message"
                className="grid place-items-center w-9 h-9 rounded-lg bg-[var(--primary)] text-white disabled:opacity-40 hover:bg-[var(--primary-dark)] transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

/* =================================================================== */
/*  Root App                                                           */
/* =================================================================== */

export default function App() {
  const [dark, setDark] = useState(true)
  const [lang, setLang] = useState("EN")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [results, setResults] = useState(null)
  const [isDemo, setIsDemo] = useState(false)

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark)
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", dark ? "#0f172a" : "#f1f5f9")
  }, [dark])

  const handleResults = useCallback((data, demo) => {
    setResults(data)
    setIsDemo(demo)
    setTimeout(
      () =>
        document
          .getElementById("results")
          ?.scrollIntoView({ behavior: "smooth" }),
      120,
    )
  }, [])

  return (
    <div className="min-h-screen">
      <Navbar
        dark={dark}
        toggleDark={() => setDark((d) => !d)}
        lang={lang}
        setLang={setLang}
      />

      <Hero />

      <ProfileForm
        onResults={handleResults}
        loading={loading}
        setLoading={setLoading}
        setError={setError}
      />

      {error && (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 -mt-12 mb-4">
          <div className="glass rounded-xl px-4 py-3 text-sm text-[var(--amber)] flex items-center gap-2">
            <AlertTriangle size={16} />
            {error}
          </div>
        </div>
      )}

      {results && <Results data={results} isDemo={isDemo} />}

      <StatsDashboard />

      <footer className="border-t py-8 px-4 text-center text-sm text-[var(--muted)]">
        <p className="flex items-center justify-center gap-2">
          <Landmark size={16} className="text-[var(--primary)]" />
          Scheme Navigator — Empowering every citizen of India.
        </p>
      </footer>

      <Chatbot />
    </div>
  )
}
